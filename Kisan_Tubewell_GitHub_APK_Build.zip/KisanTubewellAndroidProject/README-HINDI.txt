किसान ट्यूबवेल हिसाब - Android APK Build

इस प्रोजेक्ट को GitHub repository में अपलोड करें। .github/workflows/build-apk.yml मौजूद है।
GitHub में Actions टैब खोलें, “Build Kisan Tubewell APK” workflow चुनें और Run workflow दबाएँ।
Build सफल होने पर workflow run के नीचे Artifacts में Kisan-Tubewell-debug-APK.zip मिलेगा।
उसे डाउनलोड करके Extract करें और app-debug.apk इंस्टॉल करें।

ऐप हिंदी/English, किसान प्रोफाइल, पुराने बकाया, ट्यूबवेल रन, भुगतान, रेट सेटिंग, स्टेटमेंट प्रिंट/PDF और JSON backup/restore सपोर्ट करता है।
डेटा फोन के ऐप में लोकल सेव होता है; नियमित बैकअप डाउनलोड करें।
