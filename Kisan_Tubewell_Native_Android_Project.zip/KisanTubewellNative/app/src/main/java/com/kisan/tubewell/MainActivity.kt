package com.kisan.tubewell

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private const val GREEN = 0xFF087A3B.toInt()
private const val LIGHT = 0xFFEAF6EE.toInt()
private const val BLUE = 0xFF1688D4.toInt()

class Db(context: android.content.Context) : SQLiteOpenHelper(context, "kisan_hisab.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE farmers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,old_due REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE runs(id INTEGER PRIMARY KEY AUTOINCREMENT,farmer_id INTEGER,date TEXT,start_time TEXT,end_time TEXT,hours REAL,rate REAL,amount REAL)")
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,farmer_id INTEGER,date TEXT,amount REAL,note TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
}

class MainActivity : Activity() {
    private lateinit var db: Db
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val dateNow get() = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
    private val rate get() = prefs.getFloat("rate", 250f).toDouble()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF5F8F5.toInt()) }
        val header = TextView(this).apply {
            text = "🌾  $title"; textSize = 21f; setTextColor(-1); setPadding(18, 18, 18, 18)
            setBackgroundColor(GREEN); gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(header)
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 24) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        contentBody = body
        return body
    }
    private lateinit var contentBody: LinearLayout

    private fun label(text: String, size: Float = 16f) {
        contentBody.addView(TextView(this).apply { this.text = text; textSize = size; setTextColor(0xFF24352A.toInt()); setPadding(4, 10, 4, 8) })
    }
    private fun button(text: String, color: Int = GREEN, action: () -> Unit) {
        val b = Button(this).apply { this.text = text; isAllCaps = false; textSize = 16f; setTextColor(-1); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); setOnClickListener { action() } }
        val lp = LinearLayout.LayoutParams(-1, 54); lp.setMargins(0, 6, 0, 6); contentBody.addView(b, lp)
    }
    private fun card(text: String) {
        contentBody.addView(TextView(this).apply { this.text = text; textSize = 16f; setTextColor(0xFF1C3325.toInt()); setPadding(15, 15, 15, 15); setBackgroundColor(LIGHT) }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 9) })
    }
    private fun showHome() {
        val body = base("किसान ट्यूबवेल हिसाब")
        val farmers = count("farmers"); val due = totalDue()
        card("आपका हिसाब, हमेशा आपके साथ\nकुल किसान: $farmers     कुल बाकी: ₹${money(due)}\nप्रति घंटा दर: ₹${money(rate)}")
        button("👨‍🌾  किसान जोड़ें") { farmerDialog() }
        button("⏱️  ट्यूबवेल चलने की एंट्री", BLUE) { runDialog() }
        button("₹  भुगतान एंट्री", 0xFFEA8A12.toInt()) { paymentDialog() }
        button("📒  किसान सूची और बकाया", 0xFF7A45B5.toInt()) { showFarmers() }
        button("📊  रिपोर्ट और PDF", 0xFF008F83.toInt()) { showReport() }
        button("☁️  बैकअप / Restore", 0xFF2868B2.toInt()) { backupScreen() }
        button("⚙️  सेटिंग – प्रति घंटा रेट", 0xFF59636B.toInt()) { rateDialog() }
        card("🔒 डेटा इस फोन में सेव रहता है। फोन बदलने या ऐप हटाने से पहले बैकअप जरूर लें। Google Drive चुनने के लिए बैकअप बनाते समय Drive लोकेशन चुनें।")
    }
    private fun count(table: String): Int = db.readableDatabase.rawQuery("SELECT COUNT(*) FROM $table", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    private fun totalDue(): Double {
        val c = db.readableDatabase.rawQuery("SELECT COALESCE(SUM(old_due),0) FROM farmers", null); var total = 0.0
        c.use { if (it.moveToFirst()) total = it.getDouble(0) }
        val r = db.readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM runs", null); r.use { if (it.moveToFirst()) total += it.getDouble(0) }
        val p = db.readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments", null); p.use { if (it.moveToFirst()) total -= it.getDouble(0) }
        return total
    }
    private fun money(v: Double) = String.format(Locale.getDefault(), "%.2f", v).trimEnd('0').trimEnd('.')
    private fun input(hint: String, type: Int = InputType.TYPE_CLASS_TEXT, value: String = ""): EditText = EditText(this).apply { this.hint = hint; inputType = type; setText(value) }
    private fun dialog(title: String, view: View, positive: String = "सेव करें", onSave: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setView(view).setNegativeButton("रद्द", null).setPositiveButton(positive) { _, _ -> onSave() }.show()
    }
    private fun farmerDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 4, 22, 0) }
        val name = input("किसान का नाम"); val phone = input("मोबाइल नंबर", InputType.TYPE_CLASS_PHONE); val due = input("पुराना बकाया (₹)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL, "0")
        box.addView(name); box.addView(phone); box.addView(due)
        dialog("नया किसान जोड़ें", box) {
            if (name.text.isNotBlank()) { val v = ContentValues().apply { put("name", name.text.toString()); put("phone", phone.text.toString()); put("old_due", due.text.toString().toDoubleOrNull() ?: 0.0) }; db.writableDatabase.insert("farmers", null, v); showHome() }
        }
    }
    private data class Farmer(val id: Long, val name: String)
    private fun farmerList(): List<Farmer> {
        val list = mutableListOf<Farmer>(); db.readableDatabase.rawQuery("SELECT id,name FROM farmers ORDER BY name", null).use { while (it.moveToNext()) list.add(Farmer(it.getLong(0), it.getString(1))) }; return list
    }
    private fun farmerSpinner(list: List<Farmer>): Spinner {
        val s = Spinner(this); s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, list.map { "${it.name}  (#${it.id})" }); return s
    }
    private fun runDialog() {
        val fs = farmerList(); if (fs.isEmpty()) { toast("पहले किसान जोड़ें"); farmerDialog(); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 4, 22, 0) }
        val sp = farmerSpinner(fs); val date = input("तारीख", value = dateNow); val start = input("शुरू समय (जैसे 06:30)"); val end = input("बंद समय (जैसे 09:00)"); val r = input("प्रति घंटा रेट (₹)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL, money(rate))
        listOf(sp, date, start, end, r).forEach { box.addView(it) }
        dialog("ट्यूबवेल एंट्री", box) {
            val a = minutes(start.text.toString()); val b = minutes(end.text.toString()); if (a == null || b == null) { toast("समय HH:MM में लिखें"); return@dialog }
            var mins = b - a; if (mins < 0) mins += 1440; val hours = mins / 60.0; val rr = r.text.toString().toDoubleOrNull() ?: rate
            val v = ContentValues().apply { put("farmer_id", fs[sp.selectedItemPosition].id); put("date", date.text.toString()); put("start_time", start.text.toString()); put("end_time", end.text.toString()); put("hours", hours); put("rate", rr); put("amount", hours * rr) }
            db.writableDatabase.insert("runs", null, v); showHome(); toast("${money(hours)} घंटे, बिल ₹${money(hours * rr)}")
        }
    }
    private fun minutes(s: String): Int? = try { val p = s.trim().split(":"); if (p.size != 2) null else { val h = p[0].toInt(); val m = p[1].toInt(); if (h !in 0..23 || m !in 0..59) null else h * 60 + m } } catch (_: Exception) { null }
    private fun paymentDialog() {
        val fs = farmerList(); if (fs.isEmpty()) { toast("पहले किसान जोड़ें"); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 4, 22, 0) }; val sp = farmerSpinner(fs); val amount = input("जमा राशि (₹)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL); val date = input("तारीख", value = dateNow); val note = input("नोट (वैकल्पिक)")
        listOf(sp, amount, date, note).forEach { box.addView(it) }
        dialog("भुगतान दर्ज करें", box) { val a = amount.text.toString().toDoubleOrNull() ?: 0.0; if (a > 0) { val v = ContentValues().apply { put("farmer_id", fs[sp.selectedItemPosition].id); put("amount", a); put("date", date.text.toString()); put("note", note.text.toString()) }; db.writableDatabase.insert("payments", null, v); showHome() } }
    }
    private fun farmerBalance(id: Long, old: Double): Double {
        var x = old
        db.readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM runs WHERE farmer_id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) x += it.getDouble(0) }
        db.readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE farmer_id=?", arrayOf(id.toString())).use { if (it.moveToFirst()) x -= it.getDouble(0) }
        return x
    }
    private fun showFarmers() {
        base("किसान सूची / बकाया")
        val c = db.readableDatabase.rawQuery("SELECT id,name,phone,old_due FROM farmers ORDER BY name", null)
        c.use { while (it.moveToNext()) { val id = it.getLong(0); val name = it.getString(1); val phone = it.getString(2) ?: ""; val old = it.getDouble(3); card("👨‍🌾 $name\nमोबाइल: $phone\nबाकी राशि: ₹${money(farmerBalance(id, old))}") } }
        button("+ किसान जोड़ें") { farmerDialog() }; button("⌂ होम") { showHome() }
    }
    private fun showReport() {
        base("रिपोर्ट / स्टेटमेंट")
        val fs = farmerList(); label("किसान का हिसाब और कुल बकाया")
        fs.forEach { f ->
            var old = 0.0; db.readableDatabase.rawQuery("SELECT old_due FROM farmers WHERE id=?", arrayOf(f.id.toString())).use { if (it.moveToFirst()) old = it.getDouble(0) }
            card("${f.name}   •   बाकी ₹${money(farmerBalance(f.id, old))}")
        }
        button("📄 PDF स्टेटमेंट सेव करें", BLUE) { createPdf() }
        button("⌂ होम") { showHome() }
    }
    private fun rateDialog() {
        val e = input("नया प्रति घंटा रेट (₹)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL, money(rate))
        dialog("रेट सेटिंग", e) { val n = e.text.toString().toFloatOrNull(); if (n != null && n > 0) { prefs.edit().putFloat("rate", n).apply(); showHome() } }
    }
    private fun backupScreen() {
        base("बैकअप और Restore")
        card("बैकअप फाइल को Google Drive में भी सेव कर सकते हैं: फाइल चुनने वाली स्क्रीन में Drive चुनें। नए फोन में उसी फाइल से Restore करें।")
        button("☁️ बैकअप बनाएं (Drive / फोन)", BLUE) { val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "KisanTubewellBackup_${dateNow.replace('-', '_')}.json") }; startActivityForResult(i, 101) }
        button("📥 बैकअप Restore करें", 0xFFEA8A12.toInt()) { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }; startActivityForResult(i, 102) }
        button("⌂ होम") { showHome() }
    }
    private fun exportJson(): String {
        val out = JSONObject(); val d = db.readableDatabase
        for (table in listOf("farmers", "runs", "payments")) {
            val arr = JSONArray(); d.rawQuery("SELECT * FROM $table", null).use { c -> while (c.moveToNext()) { val row = JSONObject(); for (i in 0 until c.columnCount) { val key = c.getColumnName(i); when (c.getType(i)) { 1 -> row.put(key, c.getLong(i)); 2 -> row.put(key, c.getDouble(i)); 3 -> row.put(key, c.getString(i)); else -> row.put(key, JSONObject.NULL) } }; arr.put(row) } }; out.put(table, arr)
        }
        out.put("hourly_rate", rate); out.put("backup_date", dateNow); out.put("format_version", 1); return out.toString(2)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data); if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 101) { contentResolver.openOutputStream(uri)?.use { it.write(exportJson().toByteArray(Charsets.UTF_8)) }; toast("बैकअप सफलतापूर्वक सेव हो गया") }
            if (requestCode == 102) { val text = contentResolver.openInputStream(uri)!!.bufferedReader().use(BufferedReader::readText); importJson(text); toast("डेटा Restore हो गया"); showHome() }
            if (requestCode == 103) { buildPdf(uri) }
        } catch (e: Exception) { toast("काम पूरा नहीं हुआ: ${e.message}") }
    }
    private fun importJson(text: String) {
        val obj = JSONObject(text); if (!obj.has("farmers") || !obj.has("runs") || !obj.has("payments")) throw IllegalArgumentException("यह बैकअप फाइल नहीं है")
        val d = db.writableDatabase; d.beginTransaction()
        try {
            d.delete("payments", null, null); d.delete("runs", null, null); d.delete("farmers", null, null)
            for (table in listOf("farmers", "runs", "payments")) {
                val arr = obj.getJSONArray(table)
                for (i in 0 until arr.length()) { val row = arr.getJSONObject(i); val v = ContentValues(); val keys = row.keys(); while (keys.hasNext()) { val k = keys.next(); val value = row.get(k); when (value) { JSONObject.NULL -> v.putNull(k); is Number -> v.put(k, value.toDouble()); else -> v.put(k, value.toString()) } }; d.insertOrThrow(table, null, v) }
            }
            if (obj.has("hourly_rate")) prefs.edit().putFloat("rate", obj.getDouble("hourly_rate").toFloat()).apply()
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    private fun createPdf() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE, "Kisan_Hisab_${dateNow.replace('-', '_')}.pdf") }; startActivityForResult(i, 103)
        pendingPdf = true
    }
    private var pendingPdf = false
    private fun buildPdf(uri: Uri) {
        val pdf = PdfDocument(); val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create(); val page = pdf.startPage(pageInfo); val p = Paint().apply { textSize = 16f; color = 0xFF17251B.toInt() }
        var y = 48f; page.canvas.drawText("Kisan Tubewell Hisab - Statement", 40f, y, p); y += 32
        page.canvas.drawText("Date: $dateNow", 40f, y, p); y += 30
        val c = db.readableDatabase.rawQuery("SELECT id,name,old_due FROM farmers ORDER BY name", null)
        c.use { while (it.moveToNext() && y < 790) { val id = it.getLong(0); val name = it.getString(1); val bal = farmerBalance(id, it.getDouble(2)); page.canvas.drawText("$name : Rs. ${money(bal)}", 40f, y, p); y += 24 } }
        page.canvas.drawText("Total due: Rs. ${money(totalDue())}", 40f, y + 15, p); pdf.finishPage(page)
        contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }; pdf.close(); toast("PDF सेव हो गया")
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
