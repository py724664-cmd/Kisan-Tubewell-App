किसान ट्यूबवेल हिसाब - Native Android प्रोजेक्ट

यह WebView/HTML ऐप नहीं है। UI Android के Native Kotlin Views से बना है और डेटा SQLite में सेव होता है।

फीचर:
- किसान का नाम, मोबाइल, पुराना बकाया
- ट्यूबवेल शुरू/बंद समय, अवधि और बिल की गणना
- प्रति घंटा रेट बदलना (नया रेट केवल नई एंट्री पर लागू)
- भुगतान एंट्री और बाकी राशि
- किसान सूची और PDF रिपोर्ट
- JSON बैकअप / Restore
- Android फाइल पिकर से Google Drive या फोन में बैकअप फाइल सेव/खोल सकते हैं (Drive ऐप/कनेक्शन उपलब्ध होना चाहिए)
- हिंदी UI और ऐप लोगो

APK बनाने के लिए:
1. GitHub repository में इस ZIP की अंदर की सभी फाइलें upload करें ताकि app, build.gradle, settings.gradle और .github फोल्डर repository के root में हों।
2. Actions टैब खोलें। Build Kisan Tubewell Native APK workflow चलने दें।
3. सफल run के नीचे Artifacts से Kisan-Tubewell-Native-APK डाउनलोड करें। ZIP extract करके app-debug.apk install करें।

बैकअप:
- ऐप > बैकअप / Restore > बैकअप बनाएं। फाइल चुनने वाली स्क्रीन में Google Drive चुनकर सेव किया जा सकता है।
- नए फोन पर ऐप इंस्टॉल करें > बैकअप / Restore > Restore करें > पुरानी JSON फाइल चुनें।
- ऐप हटाने से पहले Drive या किसी सुरक्षित जगह पर बैकअप जरूर रखें।
- फिलहाल Drive पर स्वचालित दैनिक अपलोड नहीं है; Drive बैकअप उपयोगकर्ता द्वारा चुनी गई फाइल के जरिए होता है।
